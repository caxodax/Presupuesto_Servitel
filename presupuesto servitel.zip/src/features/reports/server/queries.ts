import { createClient } from "@/lib/supabase/server"
import { requireAuth, enforceCompanyScope } from "@/lib/permissions"

export async function getConsolidatedReport(filters: {
    startDate: string
    endDate: string
    companyId?: number
    branchId?: number
    categoryId?: number
    subcategoryId?: number
    groupId?: number
}) {
    const user = await requireAuth()
    const supabase = await createClient()
    const scope = enforceCompanyScope(user)

    const finalCompanyId = scope.companyId || filters.companyId

    // Construcción de consultas dinámicas con Joins para nombres
    let incomesQuery = supabase
        .from('Income')
        .select(`
            amountUSD, 
            date, 
            categoryId, 
            category:Category(name),
            company:Company(name),
            branch:Branch(name),
            companyAccount:CompanyAccount(
                globalAccount:GlobalAccount(type)
            )
        `)
        .gte('date', filters.startDate)
        .lte('date', filters.endDate)

    let expensesQuery = supabase
        .from('Invoice')
        .select(`
            amountUSD, 
            date, 
            company:Company(name),
            allocation:BudgetAllocation(
                categoryId, 
                subcategoryId, 
                category:Category(name), 
                budget:Budget(
                    branchId, 
                    branch:Branch(name)
                ),
                companyAccount:CompanyAccount(
                    globalAccount:GlobalAccount(type)
                )
            )
        `)
        .eq('status', 'REGISTERED')
        .gte('date', filters.startDate)
        .lte('date', filters.endDate)

    if (finalCompanyId) {
        incomesQuery = incomesQuery.eq('companyId', finalCompanyId)
        expensesQuery = expensesQuery.eq('companyId', finalCompanyId)
    }

    // Aplicar filtros granulares
    if (filters.branchId) {
        incomesQuery = incomesQuery.eq('branchId', filters.branchId)
        expensesQuery = expensesQuery.filter('allocation.budget.branchId', 'eq', filters.branchId)
    }
    if (filters.categoryId) {
        incomesQuery = incomesQuery.eq('categoryId', filters.categoryId)
        expensesQuery = expensesQuery.filter('allocation.categoryId', 'eq', filters.categoryId)
    }
    if (filters.subcategoryId) {
        incomesQuery = incomesQuery.eq('subcategoryId', filters.subcategoryId)
        expensesQuery = expensesQuery.filter('allocation.subcategoryId', 'eq', filters.subcategoryId)
    }
    if (filters.groupId) {
        // Para filtrar por la matriz de la empresa
        incomesQuery = incomesQuery.eq('company.groupId', filters.groupId)
        expensesQuery = expensesQuery.eq('company.groupId', filters.groupId)
    }

    const [incomesRes, expensesRes] = await Promise.all([
        incomesQuery,
        expensesQuery
    ])

    if (incomesRes.error) throw new Error(`Error en ingresos: ${incomesRes.error.message}`)
    if (expensesRes.error) throw new Error(`Error en gastos: ${expensesRes.error.message}`)

    // 1. Procesamiento para Gráficos Mensuales
    const monthlyData: Record<string, { income: number; expense: number }> = {}
    
    incomesRes.data.forEach(inc => {
        const month = inc.date.substring(0, 7)
        if (!monthlyData[month]) monthlyData[month] = { income: 0, expense: 0 }
        monthlyData[month].income += Number(inc.amountUSD)
    })

    expensesRes.data.forEach(exp => {
        const month = exp.date.substring(0, 7)
        if (!monthlyData[month]) monthlyData[month] = { income: 0, expense: 0 }
        monthlyData[month].expense += Number(exp.amountUSD)
    })

    const chartData = Object.entries(monthlyData)
        .map(([name, values]) => ({ name, ...values }))
        .sort((a, b) => a.name.localeCompare(b.name))

    // 2. Desglose Detallado (Empresa > Sucursal > Periodo)
    const breakdownMap: Record<string, any> = {}

    incomesRes.data.forEach(inc => {
        const companyName = inc.company?.name || 'Empresa Desconocida'
        const branchName = inc.branch?.name || 'Sede Central / Global'
        const month = inc.date.substring(0, 7)
        const key = `${companyName}-${branchName}-${month}`

        if (!breakdownMap[key]) {
            breakdownMap[key] = { company: companyName, branch: branchName, period: month, income: 0, expense: 0 }
        }
        breakdownMap[key].income += Number(inc.amountUSD)
    })

    expensesRes.data.forEach(exp => {
        const companyName = exp.company?.name || 'Empresa Desconocida'
        const branchName = (exp.allocation as any)?.budget?.branch?.name || 'Sede Central / Global'
        const month = exp.date.substring(0, 7)
        const key = `${companyName}-${branchName}-${month}`

        if (!breakdownMap[key]) {
            breakdownMap[key] = { company: companyName, branch: branchName, period: month, income: 0, expense: 0 }
        }
        breakdownMap[key].expense += Number(exp.amountUSD)
    })

    const detailedBreakdown = Object.values(breakdownMap).map(row => ({
        ...row,
        balance: row.income - row.expense,
        status: row.income - row.expense >= 0 ? 'GAIN' : 'LOSS'
    })).sort((a, b) => b.period.localeCompare(a.period))

    // 3. Consolidación por categoría
    const categoryAnalysis: Record<string, { name: string; income: number; expense: number }> = {}
    
    incomesRes.data.forEach(inc => {
        const catName = inc.category?.name || 'Sin Categoría'
        if (!categoryAnalysis[catName]) categoryAnalysis[catName] = { name: catName, income: 0, expense: 0 }
        categoryAnalysis[catName].income += Number(inc.amountUSD)
    })

    expensesRes.data.forEach(exp => {
        const catName = (exp.allocation as any)?.category?.name || 'Sin Categoría'
        if (!categoryAnalysis[catName]) categoryAnalysis[catName] = { name: catName, income: 0, expense: 0 }
        categoryAnalysis[catName].expense += Number(exp.amountUSD)
    })

    // 4. Totales por tipo de cuenta contable
    let totalIncome = 0
    let totalCost = 0
    let totalExpense = 0

    incomesRes.data.forEach(inc => {
        const type = (inc.companyAccount as any)?.globalAccount?.type
        if (type === 'INCOME') {
            totalIncome += Number(inc.amountUSD)
        }
    })

    expensesRes.data.forEach(exp => {
        const type = (exp.allocation as any)?.companyAccount?.globalAccount?.type
        if (type === 'COST') {
            totalCost += Number(exp.amountUSD)
        } else if (type === 'EXPENSE') {
            totalExpense += Number(exp.amountUSD)
        }
    })
    
    const totalOut = totalCost + totalExpense
    
    const start = new Date(filters.startDate).getTime()
    const end = new Date(filters.endDate).getTime()
    const now = new Date().getTime()
    
    const daysElapsed = Math.max(1, (Math.min(end, now) - start) / (1000 * 60 * 60 * 24))
    const dailyAverage = totalExpense / daysElapsed
    const projectedMonthly = dailyAverage * 30
    const projectedNext30Days = totalExpense + (dailyAverage * 30)

    return {
        chartData,
        detailedBreakdown,
        categories: Object.values(categoryAnalysis),
        summary: {
            totalIncome,
            totalCost,
            totalExpense,
            totalOut,
            utility: totalIncome - totalOut,
            dailyAverage: totalOut / daysElapsed,
            projectedMonthly: (totalOut / daysElapsed) * 30,
            projectedNext30Days: totalOut + ((totalOut / daysElapsed) * 30)
        }
    }
}

/**
 * Reporte jerárquico financiero basado en el Plan de Cuentas.
 * Sumariza presupuesto y ejecución de hijos hacia padres.
 */
export async function getFinancialTreeReport(filters: {
    startDate: string
    endDate: string
    companyId: number
    branchId?: number
    budgetId?: number
}) {
    const user = await requireAuth()
    const supabase = await createClient()
    enforceCompanyScope(user, filters.companyId)

    // 1. Obtener todas las cuentas activas de la empresa con sus metadatos globales
    const { data: accounts, error: aError } = await supabase
        .from('CompanyAccount')
        .select(`
            id,
            globalAccountId,
            globalAccount:GlobalAccount(
                id, code, name, type, parentId, level, isMovementAccount
            )
        `)
        .eq('companyId', filters.companyId)
        .eq('isActive', true)

    if (aError) throw new Error(`Error al obtener plan de cuentas: ${aError.message}`)

    // 2. Obtener Asignaciones Presupuestarias (Presupuesto y Consumo acumulado)
    let allocationsQuery = supabase
        .from('BudgetAllocation')
        .select('companyAccountId, amountUSD, consumedUSD')
        .eq('Budget.companyId', filters.companyId)
    
    if (filters.budgetId) {
        allocationsQuery = allocationsQuery.eq('budgetId', filters.budgetId)
    }
    if (filters.branchId) {
        allocationsQuery = allocationsQuery.eq('Budget.branchId', filters.branchId)
    }

    const { data: allocations, error: alError } = await allocationsQuery

    // 3. Obtener Movimientos Reales en el periodo (Opcional, si queremos detalle por fecha)
    // Para el reporte jerárquico básico, usaremos los totales de BudgetAllocation
    // Pero para reportes de ingresos que no están en BudgetAllocation, necesitamos la tabla Income.
    
    const { data: incomes, error: iError } = await supabase
        .from('Income')
        .select('companyAccountId, amountUSD')
        .eq('companyId', filters.companyId)
        .gte('date', filters.startDate)
        .lte('date', filters.endDate)

    // 4. Procesar Datos en Memoria para Construir la Jerarquía
    const accountMap: Record<number, any> = {}
    
    // Inicializar mapa de cuentas
    accounts.forEach((ca: any) => {
        const ga = ca.globalAccount
        accountMap[ga.id] = {
            id: ca.id,
            globalId: ga.id,
            code: ga.code,
            name: ga.name,
            type: ga.type,
            parentId: ga.parentId,
            level: ga.level,
            isMovement: ga.isMovementAccount,
            budget: 0,
            executed: 0,
            available: 0
        }
    })

    // Sumar presupuestos y consumos (desde BudgetAllocation)
    allocations?.forEach(al => {
        // Encontrar la cuenta global correspondiente
        const ca = accounts.find(a => a.id === al.companyAccountId)
        if (ca && accountMap[ca.globalAccountId]) {
            accountMap[ca.globalAccountId].budget += Number(al.amountUSD)
            accountMap[ca.globalAccountId].executed += Number(al.consumedUSD)
        }
    })

    // Sumar ingresos (desde Income) - Nota: los ingresos suelen no estar en BudgetAllocation
    incomes?.forEach(inc => {
        const ca = accounts.find(a => a.id === inc.companyAccountId)
        if (ca && accountMap[ca.globalAccountId]) {
            // Si es una cuenta de ingreso, sumamos al ejecutado
            accountMap[ca.globalAccountId].executed += Number(inc.amountUSD)
        }
    })

    // 5. Agregación hacia arriba (Bubble up)
    // Ordenamos por nivel de mayor a menor para asegurar que los hijos se sumen a los padres
    const sortedGlobalIds = Object.keys(accountMap)
        .map(Number)
        .sort((a, b) => accountMap[b].level - accountMap[a].level)

    sortedGlobalIds.forEach(gid => {
        const acc = accountMap[gid]
        if (acc.parentId && accountMap[acc.parentId]) {
            accountMap[acc.parentId].budget += acc.budget
            accountMap[acc.parentId].executed += acc.executed
        }
    })

    // Calcular disponibles y porcentajes
    const finalData = Object.values(accountMap).map((acc: any) => ({
        ...acc,
        available: acc.budget - acc.executed,
        percent: acc.budget > 0 ? (acc.executed / acc.budget) * 100 : 0
    })).sort((a, b) => a.code.localeCompare(b.code))

    return finalData
}
